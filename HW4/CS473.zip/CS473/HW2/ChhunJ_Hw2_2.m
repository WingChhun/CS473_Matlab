%James Chhun
%Homework 2 Question 3

%Write the code that generates a normal sample with given u and sigma, and
% the code that calculates m and s fro the sample. Do the same using the
% Bayes' estiator assuming a prior distribution for u.

%Given
mu = 2.0;
sigma = 0.5;